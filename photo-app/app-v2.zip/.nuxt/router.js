import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _0b837903 = () => interopDefault(import('..\\pages\\addPhoto.vue' /* webpackChunkName: "pages/addPhoto" */))
const _5b47cece = () => interopDefault(import('..\\pages\\addQuery.vue' /* webpackChunkName: "pages/addQuery" */))
const _a6955038 = () => interopDefault(import('..\\pages\\board.vue' /* webpackChunkName: "pages/board" */))
const _b43980dc = () => interopDefault(import('..\\pages\\cart.vue' /* webpackChunkName: "pages/cart" */))
const _eef67c5e = () => interopDefault(import('..\\pages\\home.vue' /* webpackChunkName: "pages/home" */))
const _b40f4232 = () => interopDefault(import('..\\pages\\login.vue' /* webpackChunkName: "pages/login" */))
const _616d021c = () => interopDefault(import('..\\pages\\manageOrders.vue' /* webpackChunkName: "pages/manageOrders" */))
const _656d6b0a = () => interopDefault(import('..\\pages\\signup.vue' /* webpackChunkName: "pages/signup" */))
const _475e8860 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/addPhoto",
    component: _0b837903,
    name: "addPhoto"
  }, {
    path: "/addQuery",
    component: _5b47cece,
    name: "addQuery"
  }, {
    path: "/board",
    component: _a6955038,
    name: "board"
  }, {
    path: "/cart",
    component: _b43980dc,
    name: "cart"
  }, {
    path: "/home",
    component: _eef67c5e,
    name: "home"
  }, {
    path: "/login",
    component: _b40f4232,
    name: "login"
  }, {
    path: "/manageOrders",
    component: _616d021c,
    name: "manageOrders"
  }, {
    path: "/signup",
    component: _656d6b0a,
    name: "signup"
  }, {
    path: "/",
    component: _475e8860,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
